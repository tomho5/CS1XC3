/**
 * @file student.h
 * @author Tung Ho
 * @date 04/06/2022
 *
 */

/**
 * @brief The struct for student contains the first name, last name, student it, list of their grades and the total number of grades.
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50];  /**< the student's last name */
  char id[11];  /**< the student's id */
  double *grades; /**< the student's grades */
  int num_grades; /**< the student's total number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
