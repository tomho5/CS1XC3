/**
 * @file course.h
 * @author Tung Ho
 * @date 04/06/2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief The struct of a course containing the name,code,students who are taking the course and total amount of students.
 */
 
typedef struct _course 
{
  char name[100]; /**< the course name */
  char code[10];  /**< the course code */
  Student *students; /**< the students taking the course */
  int total_students; /**< the total amount of students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


